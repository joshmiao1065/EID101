#include <stdio.h>

int main() {
// s in morse code is" ..."
// o in morse code is" ---"
	printf("...");
	printf("---");
	printf("...");
	return 0;
}
