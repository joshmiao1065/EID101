#include <stdio.h>

unsigned long long calculateFactorial(int n) {
	unsigned long long factorial = 1;
	if (n < 0) {
		printf("factorial is not defined for negative numbers\n");
		return 0;
		// return 0 to indicate an error
	}
	for (int i = 1; i <= n; i++) {
		factorial *= i;
	}
	return factorial;
}

int main() {
// arbitrary n value, n is  value we are trying to calcualte factorial of 
	int n = 5;
	unsigned long long result = calculateFactorial(n);
	
	if (result !=0) {
		printf("%d! = %11u\n", n, result);
	}
	return 0;
}


