#include <stdio.h>
#include <unistd.h>

int main() {
	for(int  rate_ms = 10; rate_ms <= 1000; rate_ms += 10) {
		printf("message at %dms interval: test\n", rate_ms);
		usleep(rate_ms * 1000);
	}
return 0;
}
