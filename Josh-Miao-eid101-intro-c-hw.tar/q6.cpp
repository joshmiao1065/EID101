#include <stdio.h>
#include <stdbool.h>

bool enable_motors(bool is_stationary, bool is_battery_ok, bool is_state_ready) {

	if (is_stationary && is_battery_ok && is_state_ready) {
		printf("motors enabled\n");
		return true;
	} else {
		printf("motors not enabled\n");
		return false;
	}
}

int main() {
// this is an example where the motors are not running as the battery is not ok. 
// make sure all statements are true in order to  enable motors
	bool is_stationary = true;
	bool is_battery_ok = false;
	bool is_state_ready = true;

	bool motors_enabled = enable_motors(is_stationary, is_battery_ok, is_state_ready);

	if (motors_enabled){
		printf("motors are running\n");
	} else {
		printf("motors are not running.\n");
	}
	return 0;
}

